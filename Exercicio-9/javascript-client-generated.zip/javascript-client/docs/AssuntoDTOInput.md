# ApiDocumentation.AssuntoDTOInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descricao** | **String** |  | 
**flAtivo** | **String** |  | [optional] 


