# ApiDocumentation.ProcessoDTOInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cdAssuntoId** | **Number** |  | 
**cdInteressadoId** | **Number** |  | 
**descricao** | **String** |  | 
**nuAno** | **String** |  | 
**sgOrgaoSetor** | **String** |  | 


