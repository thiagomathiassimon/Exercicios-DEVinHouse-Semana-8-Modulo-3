# ApiDocumentation.ProcessoDTOOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cdAssunto** | [**Assunto**](Assunto.md) |  | [optional] 
**cdInteressado** | [**Interessado**](Interessado.md) |  | [optional] 
**chaveProcesso** | **String** |  | [optional] 
**descricao** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**nuAno** | **String** |  | [optional] 
**nuProcesso** | **Number** |  | [optional] 
**sgOrgaoSetor** | **String** |  | [optional] 


