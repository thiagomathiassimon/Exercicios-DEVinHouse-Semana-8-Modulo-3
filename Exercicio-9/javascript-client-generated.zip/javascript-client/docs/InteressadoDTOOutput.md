# ApiDocumentation.InteressadoDTOOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dtNascimento** | **Date** |  | [optional] 
**flAtivo** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 
**nmInteressado** | **String** |  | [optional] 
**nuIdentificacao** | **String** |  | [optional] 


