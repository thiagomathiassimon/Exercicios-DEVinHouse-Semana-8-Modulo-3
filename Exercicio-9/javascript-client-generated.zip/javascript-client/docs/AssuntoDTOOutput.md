# ApiDocumentation.AssuntoDTOOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descricao** | **String** |  | [optional] 
**dtCadastro** | **Date** |  | [optional] 
**flAtivo** | **String** |  | [optional] 
**id** | **Number** |  | [optional] 


