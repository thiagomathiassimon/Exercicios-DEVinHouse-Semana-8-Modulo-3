
# ProcessoDTOInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cdAssuntoId** | **Long** |  | 
**cdInteressadoId** | **Long** |  | 
**descricao** | **String** |  | 
**nuAno** | **String** |  | 
**sgOrgaoSetor** | **String** |  | 



