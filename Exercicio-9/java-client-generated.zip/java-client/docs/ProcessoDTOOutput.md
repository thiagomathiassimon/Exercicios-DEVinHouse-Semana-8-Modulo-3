
# ProcessoDTOOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cdAssunto** | [**Assunto**](Assunto.md) |  |  [optional]
**cdInteressado** | [**Interessado**](Interessado.md) |  |  [optional]
**chaveProcesso** | **String** |  |  [optional]
**descricao** | **String** |  |  [optional]
**id** | **Long** |  |  [optional]
**nuAno** | **String** |  |  [optional]
**nuProcesso** | **Long** |  |  [optional]
**sgOrgaoSetor** | **String** |  |  [optional]



