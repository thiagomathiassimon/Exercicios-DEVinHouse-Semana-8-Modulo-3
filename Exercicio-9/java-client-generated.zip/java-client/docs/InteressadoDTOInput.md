
# InteressadoDTOInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dtNascimento** | **String** |  | 
**flAtivo** | **String** |  |  [optional]
**nmInteressado** | **String** |  | 
**nuIdentificacao** | **String** |  | 



