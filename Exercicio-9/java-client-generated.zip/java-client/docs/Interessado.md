
# Interessado

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dtNascimento** | [**LocalDate**](LocalDate.md) |  |  [optional]
**flAtivo** | **String** |  |  [optional]
**id** | **Long** |  |  [optional]
**nmInteressado** | **String** |  |  [optional]
**nuIdentificacao** | **String** |  |  [optional]



