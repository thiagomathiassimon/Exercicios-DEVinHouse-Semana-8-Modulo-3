
# Assunto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**descricao** | **String** |  |  [optional]
**dtCadastro** | [**LocalDate**](LocalDate.md) |  |  [optional]
**flAtivo** | **String** |  |  [optional]
**id** | **Long** |  |  [optional]



